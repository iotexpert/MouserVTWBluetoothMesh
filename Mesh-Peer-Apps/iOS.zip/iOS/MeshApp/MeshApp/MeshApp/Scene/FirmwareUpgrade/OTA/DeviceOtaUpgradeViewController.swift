/*
 * Copyright Cypress Semiconductor
 */

/** @file
 *
 * Device OTA Upgrade View implementation.
 */

import UIKit
import MeshFramework

class DeviceOtaUpgradeViewController: UIViewController {
    @IBOutlet weak var topNavigationItem: UINavigationItem!
    @IBOutlet weak var backBarButtonItem: UIBarButtonItem!
    @IBOutlet weak var settingsBarButtomItem: UIBarButtonItem!
    @IBOutlet weak var otaUpgradeTitleLabel: UILabel!
    @IBOutlet weak var otaDeviceNameLabel: UILabel!
    @IBOutlet weak var otaDeviceFwVersionLabel: UILabel!
    @IBOutlet weak var otaDropDownView: CustomDropDownView!
    @IBOutlet weak var otaBackgroundView: UIView!
    @IBOutlet weak var otaDeviceFiwImageHintLabel: UILabel!
    @IBOutlet weak var otaFirmwareUpgradeButton: UIButton!
    @IBOutlet weak var otaProgressBar: UIProgressView!
    @IBOutlet weak var otaProgressPercentage: UILabel!
    @IBOutlet weak var otaUpgradeLogTextView: UITextView!
    @IBOutlet weak var otaUpgradingActivityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var otaDeviceTypeLable: UILabel!
    
    private var otaBasciDate = Date(timeIntervalSinceNow: 0)
    
    var deviceName: String?
    var groupName: String?  // When groupName is not nil, it comes from CmponentViewControl; if groupName is nil, it comes from FirmwareUpgradeViewController.

    var otaDevice: OtaDeviceProtocol?
    var otaFwImageNames: [String] = []
    var selectedFwImageName: String?
    
    var isPreparingForOta: Bool = false
    var otaUpdatedStarted: Bool = false
    var lastTransferredPercentage: Int = -1  // indicates invalid value, will be udpated.
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("DeviceOtaUpgradeViewController, viewDidLoad")
        
        // Do any additional setup after loading the view.
        otaDevice = OtaManager.shared.activeOtaDevice
        notificationInit()
        viewInit()
        
        // [Dudley] test purpose.
        // Try to read and show the firmware version if supported before starting the OTA upgrade process.
        // Or remove it to let the App always run the OTA process by click the Firmware Upgrade button.
        DispatchQueue.main.async {
            self.otaUpgradePrepare()
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
        OtaManager.shared.resetOtaUpgradeStatus()
        super.viewDidDisappear(animated)
    }
    
    func viewInit() {
        otaUpgradeLogTextView.text = ""
        log("OTA Upgrade view loaded")
        log("OTA device type: \(otaDevice?.getDeviceType() ?? OtaDeviceType.ble)")
        log("OTA device name: \"\(otaDevice?.getDeviceName() ?? "Unknown Name")\"")
        
        topNavigationItem.rightBarButtonItem = nil  // not used currently.
        otaUpgradeLogTextView.layer.borderWidth = 1
        otaUpgradeLogTextView.layer.borderColor = UIColor.gray.cgColor
        otaUpgradeLogTextView.isEditable = false
        otaUpgradeLogTextView.isSelectable = false
        otaUpgradeLogTextView.layoutManager.allowsNonContiguousLayout = false
        
        otaDropDownView.dropDownDelegate = self
        
        otaUpdatedStarted = false
        lastTransferredPercentage = -1  // indicates invalid value, will be udpated.
        otaProgressUpdated(percentage: 0.0)
        
        guard let otaDevice = self.otaDevice else {
            print("error: DeviceOtaUpgradeViewController, viewInit, invalid otaDevice instance nil")
            log("error: invalid nil OTA device object")
            DispatchQueue.main.async {
                UtilityManager.showAlertDialogue(parentVC: self, message: "Invalid nil OTA device object.", title: "Error")
            }
            return
        }
        otaDeviceNameLabel.text = otaDevice.getDeviceName()
        otaDeviceFwVersionLabel.text = "Not Avaiable"
        otaDeviceTypeLable.text = OtaManager.getOtaDeviceTypeString(by: otaDevice.getDeviceType())
        
        otaFirmwareUpgradeButton.setTitleColor(UIColor.gray, for: .disabled)
        stopOtaUpgradingAnimating()

        DispatchQueue.main.async {
            // read and update firmware image list.
            self.firmwareImagesInit()
            self.otaDropDownView.dropListItems = self.otaFwImageNames
        }
    }
    
    func notificationInit() {
        /* [Dudley]: When do firmware OTA, the mesh notification should be suppressed to avoid any confusion.
        NotificationCenter.default.addObserver(self, selector: #selector(notificationHandler(_:)),
                                               name: Notification.Name(rawValue: MeshNotificationConstants.MESH_CLIENT_NODE_CONNECTION_STATUS_CHANGED), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(notificationHandler(_:)),
                                               name: Notification.Name(rawValue: MeshNotificationConstants.MESH_CLIENT_NETWORK_LINK_STATUS_CHANGED), object: nil)
         NotificationCenter.default.addObserver(self, selector: #selector(notificationHandler(_:)),
         name: Notification.Name(rawValue: MeshNotificationConstants.MESH_NETWORK_DATABASE_CHANGED), object: nil)
        */
        
        NotificationCenter.default.addObserver(self, selector: #selector(notificationHandler(_:)),
                                               name: Notification.Name(rawValue: OtaConstants.Notification.OTA_STATUS_UPDATED), object: nil)
    }
    
    @objc func notificationHandler(_ notification: Notification) {
        guard let userInfo = notification.userInfo else {
            return
        }
        switch notification.name {
        case Notification.Name(rawValue: MeshNotificationConstants.MESH_CLIENT_NODE_CONNECTION_STATUS_CHANGED):
            if let nodeConnectionStatus = MeshNotificationConstants.getNodeConnectionStatus(userInfo: userInfo) {
                self.showToast(message: "Device \"\(nodeConnectionStatus.componentName)\" \((nodeConnectionStatus.status == MeshConstants.MESH_CLIENT_NODE_CONNECTED) ? "has connected." : "is unreachable").")
            }
        case Notification.Name(rawValue: MeshNotificationConstants.MESH_CLIENT_NETWORK_LINK_STATUS_CHANGED):
            if let linkStatus = MeshNotificationConstants.getLinkStatus(userInfo: userInfo) {
                self.showToast(message: "Mesh network has \((linkStatus.isConnected) ? "connected" : "disconnected").")
            }
        case Notification.Name(rawValue: MeshNotificationConstants.MESH_NETWORK_DATABASE_CHANGED):
            if let networkName = MeshNotificationConstants.getNetworkName(userInfo: userInfo) {
                self.showToast(message: "Database of mesh network \(networkName) has changed.")
            }
        case Notification.Name(rawValue: OtaConstants.Notification.OTA_STATUS_UPDATED):
            if let otaStatus = OtaConstants.Notification.getOtaNotificationData(userInfo: userInfo) {
                let otaState = OtaUpgrader.OtaState(rawValue: otaStatus.otaState) ?? OtaUpgrader.OtaState.idle
                if otaStatus.errorCode == OtaErrorCode.SUCCESS {
                    if otaStatus.otaState == OtaUpgrader.OtaState.idle.rawValue {
                        log("OTA state: \(otaStatus.description).")
                    } else if otaStatus.otaState == OtaUpgrader.OtaState.readAppInfo.rawValue {
                        // try to get and show the read firmware version from remote device.
                        let appInfo = String(otaStatus.description.trimmingCharacters(in: CharacterSet.whitespaces))
                        log("OTA state: \(otaState.description) finished success. \(appInfo)")
                        var version = ""
                        if let otaDevice = self.otaDevice, otaDevice.getDeviceType() == .mesh, appInfo.hasPrefix("CID:") {
                            let componentInfoValue = MeshComponentInfo(componentInfo: appInfo)
                            version = componentInfoValue.VID
                        } else {
                            let appVersion = String(appInfo.split(separator: " ").last ?? "")
                            let characterSet = CharacterSet(charactersIn: "0123456789.")
                            version = appVersion.trimmingCharacters(in: characterSet)
                        }
                        if !version.isEmpty {
                            otaDeviceFwVersionLabel.text = version
                        }
                    } else if otaStatus.otaState == OtaUpgrader.OtaState.dataTransfer.rawValue {
                        if otaStatus.transferredImageSize == 0 {
                            log("OTA state: \(otaState.description) started.")
                        }
                        // Update and log firmware image download percentage value.
                        otaProgressUpdated(percentage: Float(otaStatus.transferredImageSize) / Float(otaStatus.fwImageSize))
                    } else if otaStatus.otaState == OtaUpgrader.OtaState.complete.rawValue {
                        otaUpdatedStarted = false
                        // OTA upgrade process finished, navigate to previous view controller if success.
                        self.log("done: OTA upgrade completed success.\n")
                        self.stopOtaUpgradingAnimating()
                        if !self.isPreparingForOta {
                            UtilityManager.showAlertDialogue(parentVC: self,
                                                             message: "Congratulation! OTA process has finshed successfully.",
                                                             title: "Success", completion: nil,
                                                             action: UIAlertAction(title: "OK", style: .default,
                                                                                   handler: { (action) in
                                                                                    self.onLeftBarButtonItemClick(self.backBarButtonItem)
                                                             }))
                        }
                        self.isPreparingForOta = false
                    } else {
                        // Log normal OTA upgrade successed step.
                        log("OTA state: \(otaState.description) finished success.")
                    }
                } else {
                    if otaStatus.otaState == OtaUpgrader.OtaState.complete.rawValue {
                        otaUpdatedStarted = false
                        // OTA upgrade process finished
                        self.log("done: OTA upgrade stopped with error. Error Code: \(otaStatus.errorCode), \(otaStatus.description)\n")
                        self.stopOtaUpgradingAnimating()
                        if !self.isPreparingForOta {
                            UtilityManager.showAlertDialogue(parentVC: self,
                                                             message: "Oops! OTA process stopped with some error, please reset device and retry again later.")
                        } else {
                            if otaStatus.errorCode == OtaErrorCode.ERROR_DEVICE_OTA_NOT_SUPPORTED {
                                UtilityManager.showAlertDialogue(parentVC: self,
                                                                 message: "Oops! Target device doesn't support Cypress OTA function, please select the device that support Cypress OTA function and try again.",
                                                                 title: "Error", completion: nil,
                                                                 action: UIAlertAction(title: "OK", style: .default,
                                                                                       handler: { (action) in
                                                                                        self.onLeftBarButtonItemClick(self.backBarButtonItem)
                                                                 }))
                            } else {
                                self.log("Please select the firmare image, then click the \"Firmware Upgrade\" button to try again.\n\n")
                            }
                        }
                        self.isPreparingForOta = false
                    } else {
                        // Log normal OTA upgrade failed step.
                        log("error: OTA state: \(otaState.description) failed. Error Code:\(otaStatus.errorCode), message:\(otaStatus.description)")
                    }
                }
            }
        default:
            break
        }
    }
    
    //
    // This function will try to connect to the OTA device, then try to discover OTA services,
    // try and read the AppInfo and update to UI if possible.
    // Also, to call this function alonely can help to verify the feature of connecting to different OTA devices.
    //
    func otaUpgradePrepare() {
        guard let otaDevice = self.otaDevice else {
            print("error: DeviceOtaUpgradeViewController, otaUpgradePrepare, invalid OTA device instance")
            log("error: invalid nil OTA device object")
            UtilityManager.showAlertDialogue(parentVC: self, message: "Invalid nil OTA device object.")
            return
        }
        
        isPreparingForOta = true
        startOtaUpgradingAnimating()
        let error = otaDevice.prepareOta()
        guard error == OtaErrorCode.SUCCESS else {
            stopOtaUpgradingAnimating()
            if error == OtaErrorCode.BUSYING {
                return
            }
            print("error: DeviceOtaUpgradeViewController, otaUpgradePrepare, failed to prepare for OTA")
            self.log("error: failed to prepare for OTA, error:\(error)")
            UtilityManager.showAlertDialogue(parentVC: self, message: "Failed to prepare for OTA. Error Code: \(error).", title: "Error")
            return
        }
    }
    
    func firmwareImagesInit() {
        let meshFwPath = "mesh/fwImages"
        let fwImagesPath = NSHomeDirectory() + "/Documents/" + meshFwPath
        var isDirectory = ObjCBool(false)
        let exists = FileManager.default.fileExists(atPath: fwImagesPath, isDirectory: &isDirectory)
        if !exists || !isDirectory.boolValue {
            print("DeviceOtaUpgradeViewController, firmwareImagesInit, \(fwImagesPath) not exsiting")
            UtilityManager.showAlertDialogue(parentVC: self, message: "Firmware images under App Document dirctory with path \"\(meshFwPath)\" not found. Please copy valid firmware images into your device, then try again later.", title: "Error")
            return
        }
        
        otaFwImageNames.removeAll()
        if let files = try? FileManager.default.contentsOfDirectory(atPath: fwImagesPath) {
            for fileName in files {
                if fileName.hasSuffix(".bin") {
                    otaFwImageNames.append(fileName)
                    print("DeviceOtaUpgradeViewController, firmwareImagesInit, found images: \(fileName)")
                }
            }
        }
    }
    
    func otaProgressUpdated(percentage: Float) {
        let pct: Float = (percentage > 1.0) ? 1.0 : ((percentage < 0.0) ? 0.0 : percentage)
        let latestPercentage = Int(pct * 100)
        otaProgressPercentage.text = String(format: "%d", latestPercentage) + "%"
        otaProgressBar.progress = percentage

        if otaUpdatedStarted, lastTransferredPercentage != latestPercentage {
            log("transferred size: \(latestPercentage)%%")
            lastTransferredPercentage = latestPercentage
        }
    }
    
    func log(_ message: String) {
        let seconds = Date().timeIntervalSince(otaBasciDate)
        let msg = String(format: "[%.3f] \(message)\n", seconds)
        otaUpgradeLogTextView.text += msg
        let bottom = NSRange(location: otaUpgradeLogTextView.text.count, length: 1)
        otaUpgradeLogTextView.scrollRangeToVisible(bottom)
    }
    
    @IBAction func onOtaFirmwareUpgradeButtonClick(_ sender: UIButton) {
        print("DeviceOtaUpgradeViewController, onOtaFirmwareUpgradeButtonClick")
        log("OTA update button triggerred")
        otaUpdatedStarted = false
        lastTransferredPercentage = -1  // indicates invalid value, will be udpated.
        otaProgressUpdated(percentage: 0.0)
        
        guard let otaDevice = self.otaDevice else {
            print("error: DeviceOtaUpgradeViewController, onOtaFirmwareUpgradeButtonClick, invalid OTA device instance")
            log("error: invalid nil OTA device object")
            UtilityManager.showAlertDialogue(parentVC: self, message: "Invalid nil OTA device object.")
            return
        }
        var fwImagePath = NSHomeDirectory() + "/Documents/mesh/fwImages/"
        guard let fwImageName = self.selectedFwImageName else {
            print("error: DeviceOtaUpgradeViewController, onOtaFirmwareUpgradeButtonClick, no firmware image selected")
            log("error: no firmware image selected")
            UtilityManager.showAlertDialogue(parentVC: self, message: "Please select a firmware image firstly, then try again.")
            return
        }
        
        fwImagePath = fwImagePath + fwImageName
        var isDirectory = ObjCBool(false)
        let exists = FileManager.default.fileExists(atPath: fwImagePath, isDirectory: &isDirectory)
        guard exists, !isDirectory.boolValue, let fwImageData = FileManager.default.contents(atPath: fwImagePath) else {
            print("error: DeviceOtaUpgradeViewController, onOtaFirmwareUpgradeButtonClick, selected firmware image not exists")
            log("error: unable to read the content of the selected firmware image")
            UtilityManager.showAlertDialogue(parentVC: self, message: "Firmware image \"\(fwImagePath)\" not found or failed to read the image file. Please copy and select valid firmware images into your device, then retry later.", title: "Error")
            return
        }
        print("DeviceOtaUpgradeViewController, onOtaFirmwareUpgradeButtonClick, otaDevice=\(otaDevice), fwImagePath=\(fwImagePath), imageSize=\(fwImageData.count)")
        
        if otaDevice.getDeviceType() != .mesh {
            UtilityManager.showAlertDialogue(
                parentVC: self,
                message: "Are you sure you want to upgrade the \"\(otaDevice.getDeviceName())\" device from \(otaDevice.getDeviceType()) device to mesh device ?\n\nClick \"OK\" button to continue.\nClick \"Cancel\" button to exit",
                title: "Warning",
                cancelHandler: { (action: UIAlertAction) in return },
                okayHandler: { (action: UIAlertAction) in self.doOtaFirmwareUpgrade(otaDevice: otaDevice, fwImage: fwImageData) }
            )
            return
        }
        doOtaFirmwareUpgrade(otaDevice: otaDevice, fwImage: fwImageData)
    }
    
    func doOtaFirmwareUpgrade(otaDevice: OtaDeviceProtocol, fwImage: Data) {
        // Try to start OTA process.
        isPreparingForOta = false
        startOtaUpgradingAnimating()
        let error = otaDevice.startOta(fwImage: fwImage)
        guard error == OtaErrorCode.SUCCESS else {
            stopOtaUpgradingAnimating()
            print("error: DeviceOtaUpgradeViewController, doOtaFirmwareUpgrade, failed to start OTA process")
            log("error: failed to start OTA process, error:\(error)")
            UtilityManager.showAlertDialogue(parentVC: self, message: "Failed to start OTA process. Error Code: \(error).", title: "Error")
            return
        }
        print("DeviceOtaUpgradeViewController, doOtaFirmwareUpgrade, OTA process running")
        log("OTA upgrade process started")
        otaUpdatedStarted = true
    }
    
    @IBAction func onLeftBarButtonItemClick(_ sender: UIBarButtonItem) {
        print("DeviceOtaUpgradeViewController, onLeftBarButtonItemClick")
        if let otaDevice = self.otaDevice, otaDevice.getDeviceType() == .mesh, let groupName = self.groupName {
            print("DeviceOtaUpgradeViewController, navigate back to ComponentViewController page)")
            UserSettings.shared.currentActiveGroupName = groupName
            UserSettings.shared.currentActiveComponentName = otaDevice.getDeviceName()
            UtilityManager.navigateToViewController(targetClass: ComponentViewController.self)
        } else {
            print("DeviceOtaUpgradeViewController, navigate to FirmwareUpgradeViewController page)")
            UtilityManager.navigateToViewController(targetClass: FirmwareUpgradeViewController.self)
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onRightBarButtonItemClick(_ sender: UIBarButtonItem) {
        print("DeviceOtaUpgradeViewController, onRightBarButtonItemClick")
    }
    
    func startOtaUpgradingAnimating() {
        otaFirmwareUpgradeButton.isEnabled = false
        otaUpgradingActivityIndicator.startAnimating()
        otaUpgradingActivityIndicator.isHidden = false
    }
    
    func stopOtaUpgradingAnimating() {
        otaUpgradingActivityIndicator.stopAnimating()
        otaUpgradingActivityIndicator.isHidden = true
        otaFirmwareUpgradeButton.isEnabled = true
    }
}

extension DeviceOtaUpgradeViewController: CustomDropDownViewDelegate {
    func customDropDwonViewWillShowDropList(_ dropDownView: CustomDropDownView) {
        print("customDropDwonViewWillShowDropList, dropListItems=\(dropDownView.dropListItems)")
    }
    
    func customDropDownViewDidUpdateValue(_ dropDownView: CustomDropDownView, selectedIndex: Int) {
        print("customDropDownViewDidUpdateValue, selectedIndex=\(selectedIndex), text=\(String(describing: dropDownView.text))")
        if let selectedText = dropDownView.text, selectedText.count > 0 {
            selectedFwImageName = selectedText
            if !isPreparingForOta {
                otaFirmwareUpgradeButton.isEnabled = true
            }
            log("selected firmware mage: \"\(selectedText)\"")
        } else {
            log("error: no firmware mage selected, please copy vaild firmware images and try again later")
            selectedFwImageName = nil
            otaFirmwareUpgradeButton.isEnabled = false
        }
    }
}
