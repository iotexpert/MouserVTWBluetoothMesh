/*
 * Copyright Cypress Semiconductor
 */

/** @file
 *
 * Mesh App relative utilities definitions.
 */

import UIKit
import Foundation
import MeshFramework

public class UtilityManager: NSObject {
    public static func validateEmail(email: String?) -> Bool {
        guard let email = email else { return false }
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Z0-9a-z.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", argumentArray: [emailRegex])
        return emailTest.evaluate(with: email)
    }
    
    // Note, if the VC's modalPresentationStyle is set to the style that it doesn't support, then will cause the crash issue.
    public static func navigateToViewController(sender: UIViewController, targetVCClass: AnyClass, modalPresentationStyle: UIModalPresentationStyle = .fullScreen, storyboard: String = "Main") {
        print("navigateToViewController, targetVCClass=\"\(String(describing:targetVCClass))\"")
        let vc = UIStoryboard(name: storyboard, bundle: nil).instantiateViewController(withIdentifier: String(describing:targetVCClass))
        vc.modalPresentationStyle = modalPresentationStyle
        sender.present(vc, animated: true, completion: nil)
    }
    
    public static func navigateToViewController(targetClass: AnyClass, storyboard: String = "Main", parentVC: UIViewController? = nil) {
        let vc = UIStoryboard(name: storyboard, bundle: nil).instantiateViewController(withIdentifier: String(describing: targetClass))
        guard vc.isKind(of: targetClass) else {
            print("error: navigateToViewController, failed to initialize instance: \(String(describing: targetClass))")
            return
        }
        print("navigateToViewController: initialize instance: \(String(describing: targetClass)) success")
        if let parentVC = parentVC {
            parentVC.navigationController?.pushViewController(vc, animated: true)
            return
        } else if let appDelegate = UIApplication.shared.delegate, let window = appDelegate.window {
            if let window = window {
                window.rootViewController = vc
                window.makeKeyAndVisible()
                return
            }
        }
        print("error: failed to navigateToViewController: \(String(describing: targetClass))")
    }
    
    public static func showAlertDialogue(parentVC: UIViewController?, message: String, title: String = "Error",
                                         completion: (() -> Void)? = nil,
                                         action: UIAlertAction = UIAlertAction(title: "OK", style: .default,
                                                                               handler: { (action) in return })) {
        if let parentVC = parentVC {
            let alertConteroller = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alertConteroller.addAction(action)
            parentVC.present(alertConteroller, animated: true, completion: completion)
        }
    }
    
    public static func showAlertDialogue(parentVC: UIViewController?,
                                         message: String,
                                         title: String = "Error",
                                         cancelHandler: @escaping (_ action: UIAlertAction) -> (),
                                         okayHandler: @escaping (_ action: UIAlertAction) -> ()) {
        if let parentVC = parentVC {
            let alertConteroller = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: { (action) in cancelHandler(action) })
            let okayAction = UIAlertAction(title: "OK", style: .default, handler: { (action) in okayHandler(action) })
            alertConteroller.addAction(cancelAction)
            alertConteroller.addAction(okayAction)
            parentVC.present(alertConteroller, animated: true, completion: nil)
        }
    }
    
    public enum Quadrant {
        case TopLeft
        case TopRight
        case BottomLeft
        case BottomRight
        case Unknown
    }
    
    public static func getQuadrant(for point: CGPoint,
                                   bound: (topPoint: CGPoint, leftPoint: CGPoint, rightPoint: CGPoint, bottomPoint: CGPoint)) -> Quadrant {
        if point.x <= bound.topPoint.x && point.y <= bound.leftPoint.y {
            return .TopLeft
        } else if point.x >= bound.topPoint.x && point.y <= bound.rightPoint.y {
            return .TopRight
        } else if point.x < bound.bottomPoint.x && point.y >= bound.leftPoint.y {
            return .BottomLeft
        } else if point.x >= bound.bottomPoint.x && point.y >= bound.rightPoint.y {
            return .BottomRight
        } else {
            return .Unknown
        }
    }
    
    public static func area(p1: CGPoint, p2: CGPoint, p3: CGPoint) -> CGFloat{
        return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y)
    }
    
    public static func pointLiesInsideTringle(point: CGPoint, tp1: CGPoint, tp2: CGPoint, tp3: CGPoint)->Bool{
        let d1 = area(p1: point, p2: tp1, p3: tp2)
        let d2 = area(p1: point, p2: tp2, p3: tp3)
        let d3 = area(p1: point, p2: tp3, p3: tp1)
        return ((d1 >= 0.0 && d2 >= 0.0 && d3 >= 0.0) || (d1 <= 0.0 && d2 <= 0.0 && d3 <= 0.0))
    }
    
    public static func getIntersectionPoint(for line1: (p1: CGPoint, p2: CGPoint),
                                            and line2: (p1: CGPoint, p2: CGPoint)) -> CGPoint {
        struct LineParameters {
            var a: CGFloat
            var b: CGFloat
            var c: CGFloat
        }
        func getLineParameters(point1: CGPoint, point2: CGPoint) -> LineParameters {
            let a = point1.y - point2.y
            let b = point2.x - point1.x
            let c = point1.x * point2.y - point1.y * point2.x
            return LineParameters(a: a, b: b, c: c)
        }
        let line1Params = getLineParameters(point1: line1.p1, point2: line1.p2)
        let line2Params = getLineParameters(point1: line2.p1, point2: line2.p2)
        let determinant = line1Params.a * line2Params.b - line2Params.a * line1Params.b
        if determinant == 0 {   // 0 indicates the two lines won't cross.
            return CGPoint.zero
        }
        let x = (line1Params.b * line2Params.c - line2Params.b * line1Params.c) / determinant
        let y = (line1Params.c * line2Params.a - line2Params.c * line1Params.a) / determinant
        return CGPoint(x: x, y: y)
    }
    
    public static func getDistance(between p1: CGPoint, and p2: CGPoint) -> CGFloat {
        return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2))
    }
    
    // The mesh component name must be in the format of "nameYYYY (XXXX)". e.g.: Light Color (0008). The address string in hexdecimal format.
    public static func getMeshAddressString(meshComponentName: String) -> String {
        let addressComponent = String(meshComponentName.trimmingCharacters(in: CharacterSet.whitespaces).suffix(7))
        if addressComponent.hasPrefix(" ("), addressComponent.hasSuffix(")") {
            let addressString = String(addressComponent.suffix(5).prefix(4))
            let characterSet = CharacterSet(charactersIn: "0123456789abcdefABCDEF")
            let leftString = addressString.trimmingCharacters(in: characterSet)
            if leftString.isEmpty {
                return addressString
            }
        }
        return ""
    }
    
    public static func getMeshAddressSuffixString(meshComponentName: String) -> String {
        return " (" + UtilityManager.getMeshAddressString(meshComponentName: meshComponentName) + ")"
    }
    
    // The mesh component name must be in the format of "nameYYYY (XXXX)". e.g.: Light Color (0008). The address string in hexdecimal format.
    public static func getMeshAddress(meshComponentName: String) -> Int {
        let upperCased = UtilityManager.getMeshAddressString(meshComponentName: meshComponentName).uppercased()
        var sum: Int = 0
        for char in upperCased.utf8 {
            sum = sum * 16 + Int(char) - 48
            if char >= 65 {    // A=65, A..F should be wrapped to 10..15.
                sum -= 7
            }
        }
        return sum
    }
    
    // the value range of percentage is 0 ~ 100
    public static func lightnessPercentageToLightPerceivedLightness(_ percentage: Double) -> Int {
        if percentage >= 100.0 {
            return MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX
        }
        if percentage <= 0.0 {
            return MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MIN
        }
        return Int(percentage * Double(MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX) / 100.0)
    }
    
    public static func lightPerceivedLightnessToLightnessPercentage(_ perceivedLightness: Int) -> Double {
        if perceivedLightness >= MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX {
            return 100.0
        }
        if perceivedLightness <= MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MIN {
            return 0.0
        }
        return (Double(perceivedLightness) * 100.0 / Double(MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX)).rounded()
    }
    
    public static func lightPerceivedLightnessToLightIntensity(_ perceivedLightness: Int) -> Int {
        if perceivedLightness >= MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX {
            return MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX
        }
        if perceivedLightness <= MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MIN {
            return MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MIN
        }
        let max = Double(MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX)
        return Int(Double(perceivedLightness) * Double(perceivedLightness) / max)
    }
    
    public static func lightIntensityToLightPerceivedLightness(_ lightIntensity: Int) -> Int {
        if lightIntensity >= MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX {
            return MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX
        }
        if lightIntensity <= MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MIN {
            return MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MIN
        }
        let max = Double(MeshConstants.LIGHT_LIGHTNESS_ACTUAL_MAX)
        let v = Double(lightIntensity) / max
        return Int(max * sqrt(v))
    }
}

extension UIViewController {
    func showToast(message: String) {
        let sceenSize = UIScreen.main.bounds.size
        
        let tempLabel = UILabel(frame: CGRect(x: 0, y: (sceenSize.height - 100), width: sceenSize.width, height: 100))
        tempLabel.font = UIFont.systemFont(ofSize: UIFont.systemFontSize)
        tempLabel.textAlignment = .center
        tempLabel.layer.cornerRadius = 5
        tempLabel.clipsToBounds = true
        tempLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        var totalLines: Int = 0
        let splitMsgs = message.components(separatedBy: "\n")
        for msg in splitMsgs {
            tempLabel.text = msg
            let textSize = tempLabel.systemLayoutSizeFitting(CGSize(width: 0, height: 0))
            let lines = ceilf(Float(textSize.width) / Float(sceenSize.width))
            totalLines += ((lines == 0) ? 1 : Int(lines))
        }
        tempLabel.text = "One Line"
        totalLines += 2
        
        let toastHeight: CGFloat = CGFloat(totalLines * Int(tempLabel.font.lineHeight))
        let toastLabel = UILabel(frame: CGRect(x: 0, y: (sceenSize.height - toastHeight), width: sceenSize.width, height: toastHeight))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center
        toastLabel.font = UIFont.systemFont(ofSize: UIFont.systemFontSize)
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 5
        toastLabel.clipsToBounds = true
        toastLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        toastLabel.numberOfLines = totalLines
        toastLabel.text = message
        
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 5.0, delay: 1.0, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }) { (isCompleted) in
            toastLabel.removeFromSuperview()
        }
    }
}
