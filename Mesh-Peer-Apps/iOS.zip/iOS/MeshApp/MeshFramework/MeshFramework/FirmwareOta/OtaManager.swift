/*
 * Copyright Cypress Semiconductor
 */

/** @file
 *
 * OTA management and interface implementation.
 */

import Foundation
import CoreBluetooth
import HomeKit

public enum OtaDeviceType {
    case ble
    case mesh
    case homeKit
}

public protocol OtaManagerDelegate {
    func onOtaDevicesUpdate()
}

public class OtaManager: NSObject {
    public static let shared = OtaManager()
    public var isOtaScanning: Bool = false
    
    // indicates that the the otaUpgradeStart() has been executed.
    public var isOtaUpgrading: Bool {
        // When do OTA prepare fisrt, then do upgrade later, the OtaUpgrader.shared.isOtaUpgradeRunning is false between
        // prepare and upgarde, but the OtaUpgrader.shared.isOtaUpgradePrepareReady should be true if prepared success,
        // so, we need to monitor the network and connection changes.
        return OtaUpgrader.shared.isOtaUpgradeRunning || (OtaUpgrader.shared.isOtaUpgradePrepareReady)
    }
    // indicates the OTA Service has been discovered when isOtaUpgrading is true.
    public var isOtaDeviceConnected: Bool {
        return OtaUpgrader.shared.isDeviceConnected
    }
    public var shouldBlockingOtherGattProcess: Bool {
        guard isOtaUpgrading else {
            return false
        }
        
        if let otaDevice = OtaManager.shared.activeOtaDevice, otaDevice.getDeviceType() == .mesh, !isOtaDeviceConnected {
            return false    // Mesh device connect requires mesh library interactive, so do not blocking.
        }
        return true
    }
    public var delegate: OtaManagerDelegate?
    
    #if os(iOS)
    // for discovering HomeKit devices for OTA.
    let mHMAccessoryBrowser = HMAccessoryBrowser()
    let mHomeManager = HMHomeManager()
    #endif  // #if os(iOS)
    
    private var mOtaDevices: [OtaDeviceProtocol] = []
    public var otaDevices: [OtaDeviceProtocol] {
        return mOtaDevices
    }

    public var activeOtaDevice: OtaDeviceProtocol?
    
    override init() {
        super.init()
        #if os(iOS)
        mHMAccessoryBrowser.delegate = self
        mHomeManager.delegate = self
        #endif // #if os(iOS)
    }
    
    public func startScan() {
        isOtaScanning = true
        didUpdateMeshDevices()
        MeshGattClient.shared.startScan()
        #if os(iOS)
        mHMAccessoryBrowser.startSearchingForNewAccessories()
        #endif  // #if os(iOS)
    }
    
    public func stopScan() {
        isOtaScanning = false
        #if os(iOS)
        mHMAccessoryBrowser.stopSearchingForNewAccessories()
        #endif  // #if os(iOS)
        MeshGattClient.shared.stopScan()
    }
    
    public func clearOtaDevices() {
        mOtaDevices.removeAll()
    }
    
    public func resetOtaUpgradeStatus() {
        OtaUpgrader.shared.otaUpgradeStatusReset()
    }
    
    public func dumpOtaStatus() {
        OtaUpgrader.shared.dumpOtaUpgradeStatus()
        print("dumpOtaStatus, isOtaScanning:\(isOtaScanning), shouldBlockingOtherGattProcess:\(OtaManager.shared.shouldBlockingOtherGattProcess)")
    }
    
    static public func getOtaDeviceTypeString(by deviceType: OtaDeviceType) -> String {
        switch deviceType {
        case .ble:
            return "LE"
        case .homeKit:
            return "HM"
        case .mesh:
            return "M"
        }
    }
    
    public func didUpdateMeshDevices() {
        if let networkName = MeshFrameworkManager.shared.getOpenedMeshNetworkName(),
            let components = MeshFrameworkManager.shared.getlAllMeshGroupComponents(groupName: networkName) {
            for component in components {
                // create mesh ota device instance.
                print("\(component)")
                self.addOtaDevice(device: OtaMeshDevice(meshName: component))
            }
        }
    }
    
    #if os(iOS)
    public func didUpdateHomeKitDevices() {
        for home in mHomeManager.homes {
            for accessory in home.accessories {
                print("home: \(home.name), \(accessory), service.count=\(accessory.services.count)")
                if validAccessoryFilter(accessory) {
                    
                    self.addOtaDevice(device: OtaHomeKitDevice(accessory: accessory))
                }
            }
        }
        
        for accessory in mHMAccessoryBrowser.discoveredAccessories {
            print("discoveredAccessories, \(accessory), service.count=\(accessory.services.count)")
            if validAccessoryFilter(accessory) {
                if validAccessoryFilter(accessory) {
                    self.addOtaDevice(device: OtaHomeKitDevice(accessory: accessory))
                }
            }
        }
    }
    #endif  // #if os(iOS)

    func addOtaDevice(device: OtaDeviceProtocol) {
        let deviceType = device.getDeviceType()
        
        #if os(iOS)
        if deviceType == .homeKit, let newDevice = device as? OtaHomeKitDevice {
            for existDevice in mOtaDevices {
                if let addedDevice = existDevice as? OtaHomeKitDevice, let newAccessory = newDevice.otaDevice as? HMAccessory,
                    let existAccessory = addedDevice.otaDevice as? HMAccessory, newAccessory.uniqueIdentifier == existAccessory.uniqueIdentifier {
                    return  // this device has been added, skip.
                }
            }
            
            // The device is new, add it.
            mOtaDevices.append(device)
            // Call the notification callback about the devices udpated if required.
            delegate?.onOtaDevicesUpdate()
            return
        }
        #endif  // #if os(iOS)
        
        if deviceType == .mesh, let newDevice = device as? OtaMeshDevice {
            for existDevice in mOtaDevices {
                if let addedDevice = existDevice as? OtaMeshDevice, newDevice.getDeviceName() == addedDevice.getDeviceName() {
                    return  // this device has been added, skip.
                }
            }
        } else if deviceType == .ble, let newDevice = device as? OtaBleDevice {
            for existDevice in mOtaDevices {
                if let addedDevice = existDevice as? OtaBleDevice, let newPeripheral = newDevice.otaDevice as? CBPeripheral,
                    let existPeripheral = addedDevice.otaDevice as? CBPeripheral, newPeripheral.identifier == existPeripheral.identifier {
                    return  // this device has been added, skip.
                }
            }
        }
        
        // The device is new, add it.
        mOtaDevices.append(device)
        // Call the notification callback about the devices udpated if required.
        delegate?.onOtaDevicesUpdate()
    }
    
    func validPeripheralFilter(_ peripheral: CBPeripheral) -> Bool {
        // TODO [opetional]:
        //      Add the peripheral device filter here is necessory.
        //      Return true will be added to OTA device list, otherwise will be ignored.
        return true
    }
    
    func validAccessoryFilter(_ accessory: HMAccessory) -> Bool {
        // TODO [opetional]:
        //      the accessory device filter here is necessory.
        //      Return true will be added to OTA device list, otherwise will be ignored.
        //  e.g.: filter based on device name.
        if !accessory.isReachable {
            return false
        }
        return true
    }
    
    func getOtaUpgraderInstance() -> OtaUpgraderProtocol? {
        guard let _ = self.activeOtaDevice else {
            print("error: OtaManager, getActiveOtaUpgraderInstance, activeOtaDeviceDelegate is nil")
            return nil
        }
        
        return OtaUpgrader.shared
    }
}

// Manage devices and operations through Bluetooth GATT protocol.
extension OtaManager {
    ///
    /// CBCentralManagerDelegate callbacks
    ///
    
    open func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        print("OtaManager, centralManager didDiscover peripheral, isOtaUpgrading:\(self.isOtaUpgrading), isOtaDeviceConnected:\(self.isOtaDeviceConnected), isOtaScanning:\(self.isOtaScanning)")
        guard self.isOtaScanning else {
            return
        }
        
        // must be connectale device.
        guard let connectable = advertisementData[CBAdvertisementDataIsConnectable] as? Bool, connectable else {
            return
        }
   
        print("OtaManager, centralManager didDiscover peripheral, \(peripheral), rssi=\(RSSI), \(advertisementData)")
        if MeshNativeHelper.isMeshProxyServiceAdvertisementData(advertisementData) {
            // all provisioined mesh devices are reterived through mesh network, so bypass all active provsioned mesh devices.
            return
        }
        
        if validPeripheralFilter(peripheral) {
            self.addOtaDevice(device: OtaBleDevice(peripheral: peripheral))
        }
    }
    
    open func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        print("OtaManager, centralManager didConnect peripheral, isOtaUpgrading:\(self.isOtaUpgrading), isOtaDeviceConnected:\(self.isOtaDeviceConnected)")
        self.activeOtaDevice?.otaDevice = peripheral
        // For mesh device, the connect event should be processed in the meshClientConnectComponent() callback function.
        if self.isOtaUpgrading, let otaDevice = self.activeOtaDevice, otaDevice.getDeviceType() != .mesh {
            print("OtaManager, centralManager didConnect peripheral:\(peripheral), otaDevice:\(otaDevice)")
            self.getOtaUpgraderInstance()?.didUpdateConnectionState(isConnected: true, error: nil)
        }
    }
    
    open func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        print("OtaManager, centralManager didFailToConnect peripheral, isOtaUpgrading:\(self.isOtaUpgrading), isOtaDeviceConnected:\(self.isOtaDeviceConnected)")
        self.activeOtaDevice?.otaDevice = nil
        if self.isOtaUpgrading {
            print("OtaManager, centralManager didFailToConnect peripheral, \(peripheral), \(String(describing: error))")
            self.getOtaUpgraderInstance()?.didUpdateConnectionState(isConnected: false, error: error)
        }
    }
    
    open func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("OtaManager, centralManager didDisconnectPeripheral peripheral, isOtaUpgrading:\(self.isOtaUpgrading), isOtaDeviceConnected:\(self.isOtaDeviceConnected)")
        self.activeOtaDevice?.otaDevice = nil
        if self.isOtaUpgrading, self.isOtaDeviceConnected {
            print("OtaManager, centralManager didDisconnectPeripheral peripheral, \(peripheral), \(String(describing: error))")
            self.getOtaUpgraderInstance()?.didUpdateConnectionState(isConnected: false, error: error)
        }
    }
    
    ///
    /// CBPeripheralDelegate callbacks
    ///
    
    open func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        print("OtaManager, peripheral didDiscoverServices, isOtaUpgrading:\(self.isOtaUpgrading), isOtaDeviceConnected:\(self.isOtaDeviceConnected)")
        guard self.isOtaUpgrading, self.isOtaDeviceConnected else {
            return
        }
        
        print("OtaManager, peripheral didDiscoverServices, \(peripheral), error:\(String(describing: error))")
        guard error == nil else {
            self.getOtaUpgraderInstance()?.didUpdateOtaServiceCharacteristicState(isDiscovered: false, error: error)
            self.activeOtaDevice?.disconnect()
            return
        }
        
        if let services = peripheral.services, services.count > 0, let service: CBService = services.filter({$0.uuid == OtaConstants.BLE.UUID_SERVICE_UPGRADE}).first {
            print("OtaManager, peripheral didDiscoverServices, GATT OTA Service found")
            
            self.activeOtaDevice?.otaService = service
            peripheral.discoverCharacteristics(nil, for: service)
        } else {
            print("OtaManager, peripheral didDiscoverServices, GATT OTA Service not found")
            self.getOtaUpgraderInstance()?.didUpdateOtaServiceCharacteristicState(isDiscovered: false, error: nil)
            self.activeOtaDevice?.disconnect()
        }
    }
    
    open func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        print("OtaManager, peripheral didDiscoverCharacteristicsFor, isOtaUpgrading:\(self.isOtaUpgrading), isOtaDeviceConnected:\(self.isOtaDeviceConnected)")
        guard let activeOtaDevice = self.activeOtaDevice, self.isOtaUpgrading, self.isOtaDeviceConnected else {
            return
        }
        
        print("OtaManager, peripheral didDiscoverCharacteristicsFor service:\(service), error:\(String(describing: error))")
        guard error == nil else {
            self.getOtaUpgraderInstance()?.didUpdateOtaServiceCharacteristicState(isDiscovered: false, error: error)
            self.activeOtaDevice?.disconnect()
            return
        }
        
        if let characteristics = service.characteristics {
            if let characteristic: CBCharacteristic = characteristics.filter({$0.uuid == OtaConstants.BLE.UUID_CHARACTERISTIC_CONTROL_POINT}).first {
                print("OtaManager, peripheral didDiscoverCharacteristicsFor service, OTA Control Point characteristic found")
                self.activeOtaDevice?.otaControlPointCharacteristic = characteristic
            }
            
            if let characteristic: CBCharacteristic = characteristics.filter({$0.uuid == OtaConstants.BLE.UUID_CHARACTERISTIC_DATA}).first {
                print("OtaManager, peripheral didDiscoverCharacteristicsFor service, OTA Data characteristic found")
                self.activeOtaDevice?.otaDataCharacteristic = characteristic
            }
            
            if let characteristic: CBCharacteristic = characteristics.filter({$0.uuid == OtaConstants.BLE.UUID_CHARACTERISTIC_APP_INFO}).first {
                print("OtaManager, peripheral didDiscoverCharacteristicsFor service, OTA App Info characteristic found")
                self.activeOtaDevice?.otaAppInfoCharacteristic = characteristic
            }
        }
        
        if activeOtaDevice.otaControlPointCharacteristic != nil, activeOtaDevice.otaDataCharacteristic != nil {
            print("OtaManager, peripheral didDiscoverCharacteristicsFor service, all OTA characteristic found in the service")
            if let appInfoCharacteristic = activeOtaDevice.otaAppInfoCharacteristic as? CBCharacteristic {
                peripheral.readValue(for: appInfoCharacteristic)
            } else {
                self.getOtaUpgraderInstance()?.didUpdateOtaServiceCharacteristicState(isDiscovered: true, error: nil)
            }
        } else {
            print("error: OtaManager, peripheral didDiscoverCharacteristicsFor service, no characteristic found in the service")
            self.getOtaUpgraderInstance()?.didUpdateOtaServiceCharacteristicState(isDiscovered: false, error: nil)
        }
    }
    
    open func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        print("OtaManager, peripheral didUpdateNotificationStateFor characteristic, isOtaUpgrading:\(self.isOtaUpgrading), isOtaDeviceConnected:\(self.isOtaDeviceConnected)")
        guard self.isOtaUpgrading, self.isOtaDeviceConnected else {
            return
        }
        
        print("OtaManager, peripheral didUpdateNotificationStateFor characteristic=\(characteristic)")
        guard let activeOtaDevice = self.activeOtaDevice else {
            print("error: OtaManager, peripheral didUpdateNotificationStateFor characteristic, activeOtaDevice is nil")
            return
        }
        guard activeOtaDevice.otaControlPointCharacteristic as? CBCharacteristic == characteristic else {
            print("warnnig: OtaManager, peripheral didUpdateNotificationStateFor characteristic, not Control Point characteristic")
            return
        }
        guard error == nil else {
            print("error: OtaManager, peripheral didUpdateNotificationStateFor characteristic, failed to enable notification, error:\(String(describing: error))")
            self.getOtaUpgraderInstance()?.didUpdateNotificationState(isEnabled: false, error: error)
            activeOtaDevice.disconnect()
            return
        }
        guard characteristic.isNotifying else {
            print("error: OtaManager, peripheral didUpdateNotificationStateFor characteristic, notification not enabled, isNotifying=\(characteristic.isNotifying)")
            self.getOtaUpgraderInstance()?.didUpdateNotificationState(isEnabled: false, error: error)
            activeOtaDevice.disconnect()
            return
        }
        
        self.getOtaUpgraderInstance()?.didUpdateNotificationState(isEnabled: true, error: nil)
    }
    
    open func peripheral(_ peripheral: CBPeripheral, didDiscoverDescriptorsFor characteristic: CBCharacteristic, error: Error?) {
        guard self.isOtaUpgrading, self.isOtaDeviceConnected else {
            return
        }
        print("OtaManager, peripheral didDiscoverDescriptorsFor characteristic=\(characteristic)")
    }
    
    open func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor descriptor: CBDescriptor, error: Error?) {
        guard self.isOtaDeviceConnected else {
            return
        }
        print("OtaManager, peripheral didUpdateValueFor descriptor=\(descriptor)")
    }
    
    open func peripheral(_ peripheral: CBPeripheral, didWriteValueFor descriptor: CBDescriptor, error: Error?) {
        guard self.isOtaUpgrading, self.isOtaDeviceConnected else {
            return
        }
        print("OtaManager, peripheral didWriteValueFor descriptor=\(descriptor)")
    }
    
    open func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        print("OtaManager, peripheral didUpdateValueFor characteristic, isOtaUpgrading:\(self.isOtaUpgrading), isOtaDeviceConnected:\(self.isOtaDeviceConnected)")
        guard self.isOtaUpgrading, self.isOtaDeviceConnected else {
            return
        }
        guard let activeOtaDevice = self.activeOtaDevice else {
            print("error: OtaManager, peripheral didUpdateValueFor characteristic, activeOtaDevice is nil")
            return
        }
        
        var data = characteristic.value
        if activeOtaDevice.getDeviceType() == .mesh, let encryptedData = data  {
            // decrpypt mesh data before send to OtaUpgrader.
            data = MeshFrameworkManager.shared.meshClientOtaDataDecrypt(componenetName: activeOtaDevice.getDeviceName(), data: encryptedData)
        }
        
        if activeOtaDevice.otaControlPointCharacteristic as? CBCharacteristic == characteristic {
            self.getOtaUpgraderInstance()?.didUpdateValueFor(characteristic: .controlPointCharacteristic, value: data, error: error)
        } else if activeOtaDevice.otaDataCharacteristic as? CBCharacteristic == characteristic {
            self.getOtaUpgraderInstance()?.didUpdateValueFor(characteristic: .dataCharacteristic, value: data, error: error)
        } else if activeOtaDevice.otaAppInfoCharacteristic as? CBCharacteristic == characteristic {
            self.getOtaUpgraderInstance()?.didUpdateValueFor(characteristic: .appInfoCharacteristic, value: data, error: error)
        }
    }
    
    open func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard self.isOtaUpgrading, self.isOtaDeviceConnected else {
            return
        }
        
        guard let activeOtaDevice = self.activeOtaDevice else {
            print("error: OtaManager, peripheral didWriteValueFor characteristic, activeOtaDevice is nil")
            return
        }
        
        if activeOtaDevice.otaControlPointCharacteristic as? CBCharacteristic == characteristic {
            activeOtaDevice.didWriteValue(for: .controlPointCharacteristic, error: error)
        } else if activeOtaDevice.otaDataCharacteristic as? CBCharacteristic == characteristic {
            activeOtaDevice.didWriteValue(for: .dataCharacteristic, error: error)
        } else if activeOtaDevice.otaAppInfoCharacteristic as? CBCharacteristic == characteristic {
            activeOtaDevice.didWriteValue(for: .appInfoCharacteristic, error: error)
        }
    }
}

#if os(iOS)
// Manage devices and operations through HomeKit protocol.
extension OtaManager: HMAccessoryBrowserDelegate, HMHomeManagerDelegate {
    private func accessoryBrowser(_ browser: HMAccessoryBrowser, didFindNewAccessory accessory: HMAccessory) {
        print("OtaDeviceManager, accessoryBrowser, HMAccessoryBrowser, didFindNewAccessory accessory: \(accessory)")
        didUpdateHomeKitDevices()
    }
    
    private func accessoryBrowser(_ browser: HMAccessoryBrowser, didRemoveNewAccessory accessory: HMAccessory) {
        print("OtaDeviceManager, accessoryBrowser, HMAccessoryBrowser, didRemoveNewAccessory accessory: \(accessory)")
        didUpdateHomeKitDevices()
    }
    
    private func homeManager(_ manager: HMHomeManager, didAdd home: HMHome) {
        print("OtaDeviceManager, homeManager, didAdd home: \(home.name)")
        didUpdateHomeKitDevices()
    }
    
    private func homeManager(_ manager: HMHomeManager, didRemove home: HMHome) {
        print("OtaDeviceManager, homeManager, didRemove home: \(home.name)")
        didUpdateHomeKitDevices()
    }
    
    private func homeManagerDidUpdateHomes(_ manager: HMHomeManager) {
        print("OtaDeviceManager, homeManager, DidUpdateHomes")
        didUpdateHomeKitDevices()
    }
    
    private func homeManagerDidUpdatePrimaryHome(_ manager: HMHomeManager) {
        print("OtaDeviceManager, homeManager, DidUpdatePrimaryHome")
        didUpdateHomeKitDevices()
    }
}
#endif  // #if os(iOS)
